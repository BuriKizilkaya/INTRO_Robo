#ifndef __USB1_CONFIG_H
#define __USB1_CONFIG_H

/* no configuration supported yet */

#endif /* __USB1_CONFIG_H */

