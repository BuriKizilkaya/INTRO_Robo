#ifndef __TmDt1_CONFIG_H
#define __TmDt1_CONFIG_H

/* no configuration supported yet */

#endif /* __TmDt1_CONFIG_H */
