#ifndef __TMOUT1_CONFIG_H
#define __TMOUT1_CONFIG_H

/* no configuration supported yet */

#endif /* __TMOUT1_CONFIG_H */
