#ifndef __DERIVATIVE_USB
#define __DERIVATIVE_USB

/* Include the derivative-specific header file */
#if 0 /* << EST */
  #include <MK20D5.h>
#else
  #include "Cpu.h"
#endif

#define USED_PIT0
#define __MK_xxx_H__

#endif

